planety  = { "Merkury": ["Najmniejsza planeta, najblizej Slonca", False, 0],
            "Wenus": ["Obrot planety Wenus zajmuje 243 dni", False, 0],
            "Ziemia": ["Jedyna znana planeta, na ktorej rozwinelo sie zycie", False, 1],
            "Mars": ["Druga po Merkurym najmniejsza planeta", False, 2],
            "Jowisz": ["Najwieksza planeta jest gazowym olbrzymem", True, 67],
            "Saturn": ["Gazowy olbrzym, drugi pod wzgledem wielkosci", True, 62],
            "Uran": ["Lodowy olbrzym z systemem pierscieni", True, 27],
            "Neptun": ["Lodowy olbrzym i najdalej od Slonca", True, 14],
            "Pluton": ["Najwieksza planeta karlowata w Ukladzie Slonecznym", False, 5]
            }


while True:
    pytanie = input("Ktora planeta Cie interesuje? ")
    if pytanie in planety.keys():
        print(planety[pytanie])
    else:
        print("Brak danych. Przepraszamy.") 

