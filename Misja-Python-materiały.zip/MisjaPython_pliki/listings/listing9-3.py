import random

def pobierz_liczbe():
    numer_z_kostki = random.randint(1, 10)
    return numer_z_kostki

liczba_losowa = pobierz_liczbe()
print(liczba_losowa)
