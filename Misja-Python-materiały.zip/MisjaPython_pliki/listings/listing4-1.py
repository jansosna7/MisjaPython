# Escape - Misja Python 
# Autor: Sean McManus / www.sean.co.uk
# Wpisal: WPISZ SWOJE IMIE

import time, random, math

###############
##  ZMIENNE  ##
###############

WIDTH = 800 #rozmiar okna
HEIGHT = 800

#zmienne GRACZA
IMIE_GRACZA = "Sean" # zastap swoim imieniem!
IMIE_PRZYJACIELA1 = "Karen" # zastap imieniem swojego przyjaciela!
IMIE_PRZYJACIELA2 = "Leo" # zastap imieniem drugiego przyjaciela!
aktualny_pokoj = 31 # poczatkowy pokoj to 31

gora_lewa_x = 100
gora_lewa_y = 150

#OBIEKTY_DEMO = [images.podloga, images.filar, images.gleba]


###############
##   MAPA    ##
###############  

MAPA_SZEROKOSC = 5
MAPA_WYSOKOSC = 10 
MAPA_ROZMIAR = MAPA_SZEROKOSC * MAPA_WYSOKOSC

MAPA_GRY = [ ["Pokoj 0 - magazyn nieuzywanych obiektow", 0, 0, False, False] ]

pokoje_zewnetrzne = range(1, 26)
for sektoryplanety in range(1, 26): #tu generowane sa pokoje 1-25
    MAPA_GRY.append( ["Zapylona powierzchnia planety", 13, 13, True, True] )

MAPA_GRY  += [
        #["Nazwa pokoju", wysokosc, szerokosc, Gorne wyjscie?, Prawe wyjscie?]
        ["Sluza powietrzna", 13, 5, True, False], # pokoj 26
        ["Maszynownia", 13, 13, False, False], # pokoj 27
        ["Centrum sterowania Poodle", 9, 13, False, True], # pokoj 28
        ["Galeria widokowa", 9, 15, False, False], # pokoj 29
        ["Lazienka zalogi", 5, 5, False, False], # pokoj 30
        ["Przedsionek do sluzy powietrznej", 7, 11, True, True], # pokoj 31
        ["Pokoj z lewym wyjsciem", 9, 7, True, False], # pokoj 32
        ["Pokoj z prawym wyjsciem", 7, 13, True, True], # pokoj 33
        ["Laboratorium", 13, 13, False, True], # pokoj 34
        ["Szklarnia", 13, 13, True, False], # pokoj 35
        ["Sypialnia kpt. " + IMIE_GRACZA, 9, 11, False, False], # pokoj 36
        ["Zachodni korytarz", 15, 5, True, True], # pokoj 37
        ["Sala konferencyjna", 7, 13, False, True], # pokoj 38
        ["Swietlica zalogi", 11, 13, True, False], # pokoj 39
        ["Glowne centrum sterowania", 14, 14, False, False], # pokoj 40
        ["Izba chorych", 12, 7, True, False], # pokoj 41
        ["Zachodni korytarz", 9, 7, True, False], # pokoj 42
        ["Centrum infrastruktury technicznej", 9, 9, False, True], # pokoj 43
        ["Centrum zarzadzania systemami", 9, 11, False, False], # pokoj 44
        ["Wejscie do centrum sterowania", 7, 7, True, False], # pokoj 45
        ["Sypialnia plk. " + IMIE_PRZYJACIELA1, 9, 11, True, True], # pokoj 46
        ["Sypialnia plk. " + IMIE_PRZYJACIELA2, 9, 11, True, True], # pokoj 47
        ["The pipewoelbow roomrks", 13, 11, True, False], # pokoj 48
        ["Biuro glownego naukowca", 9, 7, True, True], # pokoj 49
        ["Warsztat robotow", 9, 11, True, False] # pokoj 50
        ]

#proste sprawdzenie poprawnosci wpisanych powyzej danych mapy
assert len(MAPA_GRY)-1 == MAPA_ROZMIAR, "Rozmiar mapy nie pasuje do MAPA_GRY"
