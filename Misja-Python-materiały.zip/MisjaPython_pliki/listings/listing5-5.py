# Escape - Misja Python 
# Autor: Sean McManus / www.sean.co.uk
# Wpisal: WPISZ SWOJE IMIE

import time, random, math

###############
##  ZMIENNE  ##
###############

WIDTH = 800 #rozmiar okna
HEIGHT = 800

#zmienne GRACZA
IMIE_GRACZA = "Sean" # zastap swoim imieniem!
IMIE_PRZYJACIELA1 = "Karen" # zastap imieniem swojego przyjaciela!
IMIE_PRZYJACIELA2 = "Leo" # zastap imieniem drugiego przyjaciela!
aktualny_pokoj = 31 # poczatkowy pokoj to 31

gora_lewa_x = 100
gora_lewa_y = 150

OBIEKTY_DEMO = [images.podloga, images.filar, images.gleba]

LADOWNIK_SEKTOR = random.randint(1, 24)
LADOWNIK_X = random.randint(2, 11)
LADOWNIK_Y = random.randint(2, 11)


###############
##   MAPA    ##
###############  

MAPA_SZEROKOSC = 5
MAPA_WYSOKOSC = 10 
MAPA_ROZMIAR = MAPA_SZEROKOSC * MAPA_WYSOKOSC

MAPA_GRY = [ ["Pokoj 0 - magazyn nieuzywanych obiektow", 0, 0, False, False] ]

pokoje_zewnetrzne = range(1, 26)
for sektoryplanety in range(1, 26): #tu generowane sa pokoje 1-25
    MAPA_GRY.append( ["Zapylona powierzchnia planety", 13, 13, True, True] )

MAPA_GRY  += [
        #["Nazwa pokoju", wysokosc, szerokosc, Gorne wyjscie?, Prawe wyjscie?]
        ["Sluza powietrzna", 13, 5, True, False], # pokoj 26
        ["Maszynownia", 13, 13, False, False], # pokoj 27
        ["Centrum sterowania Poodle", 9, 13, False, True], # pokoj 28
        ["Galeria widokowa", 9, 15, False, False], # pokoj 29
        ["Lazienka zalogi", 5, 5, False, False], # pokoj 30
        ["Przedsionek do sluzy powietrznej", 7, 11, True, True], # pokoj 31
        ["Pokoj z lewym wyjsciem", 9, 7, True, False], # pokoj 32
        ["Pokoj z prawym wyjsciem", 7, 13, True, True], # pokoj 33
        ["Laboratorium", 13, 13, False, True], # pokoj 34
        ["Szklarnia", 13, 13, True, False], # pokoj 35
        ["Sypialnia kpt. " + IMIE_GRACZA, 9, 11, False, False], # pokoj 36
        ["Zachodni korytarz", 15, 5, True, True], # pokoj 37
        ["Sala konferencyjna", 7, 13, False, True], # pokoj 38
        ["Swietlica zalogi", 11, 13, True, False], # pokoj 39
        ["Glowne centrum sterowania", 14, 14, False, False], # pokoj 40
        ["Izba chorych", 12, 7, True, False], # pokoj 41
        ["Zachodni korytarz", 9, 7, True, False], # pokoj 42
        ["Centrum infrastruktury technicznej", 9, 9, False, True], # pokoj 43
        ["Centrum zarzadzania systemami", 9, 11, False, False], # pokoj 44
        ["Wejscie do centrum sterowania", 7, 7, True, False], # pokoj 45
        ["Sypialnia plk. " + IMIE_PRZYJACIELA1, 9, 11, True, True], # pokoj 46
        ["Sypialnia plk. " + IMIE_PRZYJACIELA2, 9, 11, True, True], # pokoj 47
        ["Pokoj z systemem rur", 13, 11, True, False], # pokoj 48
        ["Biuro glownego naukowca", 9, 7, True, True], # pokoj 49
        ["Warsztat robotow", 9, 11, True, False] # pokoj 50
        ]

#proste sprawdzenie poprawnosci wpisanych powyzej danych mapy
assert len(MAPA_GRY)-1 == MAPA_ROZMIAR, "Rozmiar mapy nie pasuje do MAPA_GRY"


####################
## TWORZENIE MAPY ##
####################

def sprawdz_typ_podlogi():
    if aktualny_pokoj in pokoje_zewnetrzne:
        return 2 # gleba
    else:
        return 0 # wykafelkowana podloga       

def generuj_mape():
# Ta funkcja tworzy mape aktualnego pokoju,
# przy uzyciu danych pokoju, scenografii i rekwizytow.
    global mapa_pokoju, szer_pokoju, wys_pokoju, nazwa_pokoju, mapa_zagrozen
    global gora_lewa_x, gora_lewa_y, ramka_przezroczystosci_sciany
    dane_pokoju = MAPA_GRY[aktualny_pokoj]
    nazwa_pokoju = dane_pokoju[0]
    wys_pokoju = dane_pokoju[1]
    szer_pokoju = dane_pokoju[2]

    typ_podlogi = sprawdz_typ_podlogi()
    if aktualny_pokoj in range(1, 21):
        dolny_brzeg = 2 #gleba
        boczny_brzeg = 2 #gleba
    if aktualny_pokoj in range(21, 26):
        dolny_brzeg = 1 #sciana
        boczny_brzeg = 2 #gleba
    if aktualny_pokoj > 25:
        dolny_brzeg = 1 #sciana
        boczny_brzeg = 1 #sciana

    # Tworzenie gornego rzedu mapy pokoju.
    mapa_pokoju=[[boczny_brzeg] * szer_pokoju]
    # Dodanie srodkowych rzedow mapy pokoju (sciana, posrodku podloga, sciana).
    for y in range(wys_pokoju - 2):
        mapa_pokoju.append([boczny_brzeg]
                        + [typ_podlogi]*(szer_pokoju - 2) + [boczny_brzeg])
    # Dodanie dolnego rzedu mapy pokoju .
    mapa_pokoju.append([dolny_brzeg] * szer_pokoju)

    # Dodanie wyjsc.
    srodkowy_rzad = int(wys_pokoju / 2)
    srodkowa_kolumna = int(szer_pokoju / 2)

    if dane_pokoju[4]: # Jesli pokoj ma prawe wyjscie
        mapa_pokoju[srodkowy_rzad][szer_pokoju - 1] = typ_podlogi
        mapa_pokoju[srodkowy_rzad+1][szer_pokoju - 1] = typ_podlogi
        mapa_pokoju[srodkowy_rzad-1][szer_pokoju - 1] = typ_podlogi

    if aktualny_pokoj % MAPA_SZEROKOSC != 1: # Jesli pokoj nie lezy po lewej stronie mapy
        pokoj_po_lewej = MAPA_GRY[aktualny_pokoj - 1]
        # Jesli pokoj po lewej ma prawe wyjscie, dodanie lewego wyjscia w tym pokoju
        if pokoj_po_lewej[4]: 
            mapa_pokoju[srodkowy_rzad][0] = typ_podlogi 
            mapa_pokoju[srodkowy_rzad + 1][0] = typ_podlogi
            mapa_pokoju[srodkowy_rzad - 1][0] = typ_podlogi

    if dane_pokoju[3]: # Jesli pokoj ma gorne wyjscie
        mapa_pokoju[0][srodkowa_kolumna] = typ_podlogi
        mapa_pokoju[0][srodkowa_kolumna + 1] = typ_podlogi
        mapa_pokoju[0][srodkowa_kolumna - 1] = typ_podlogi

    if aktualny_pokoj <= MAPA_ROZMIAR - MAPA_SZEROKOSC: # Jesli pokoj nie lezy w dolnym rzedzie
        pokoj_ponizej = MAPA_GRY[aktualny_pokoj+MAPA_SZEROKOSC]
        # Jesli pokoj ponizej ma gorne wyjscie, dodanie dolnego wyjscia w tym pokoju
        if pokoj_ponizej[3]: 
            mapa_pokoju[wys_pokoju-1][srodkowa_kolumna] = typ_podlogi 
            mapa_pokoju[wys_pokoju-1][srodkowa_kolumna + 1] = typ_podlogi
            mapa_pokoju[wys_pokoju-1][srodkowa_kolumna - 1] = typ_podlogi

###############
## EKSPLORER ##
############### 

def draw():
    global wys_pokoju, szer_pokoju, mapa_pokoju
    generuj_mape()
    screen.clear()

    for y in range(wys_pokoju):
        for x in range(szer_pokoju):
            obraz_do_narysowania = OBIEKTY_DEMO[mapa_pokoju[y][x]]
            screen.blit(obraz_do_narysowania,
                (gora_lewa_x + (x*30),
                 gora_lewa_y + (y*30) - obraz_do_narysowania.get_height()))

def ruch():
    global aktualny_pokoj
    stary_pokoj = aktualny_pokoj
    
    if keyboard.left:
        aktualny_pokoj -= 1
    if keyboard.right:
        aktualny_pokoj += 1
    if keyboard.up:
        aktualny_pokoj -= MAPA_SZEROKOSC
    if keyboard.down:
        aktualny_pokoj += MAPA_SZEROKOSC

    if aktualny_pokoj > 50:
        aktualny_pokoj = 50
    if aktualny_pokoj < 1:
        aktualny_pokoj = 1

    if aktualny_pokoj != stary_pokoj:
        print("Wchodzisz do pokoju:" + str(aktualny_pokoj))

clock.schedule_interval(ruch, 0.08)

