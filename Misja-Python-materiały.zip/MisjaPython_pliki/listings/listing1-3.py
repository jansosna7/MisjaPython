# Spacer kosmiczny
# Autor: Sean McManus
# www.sean.co.uk / www.nostarch.com

WIDTH = 800
HEIGHT = 600
gracz_x = 500
gracz_y = 550

def draw():
    screen.blit(images.tlo, (0, 0))
    screen.blit(images.statek, (130, 150))
    screen.blit(images.mars, (50, 50))


