def dodaj(pierwsza_liczba, druga_liczba):
    suma = pierwsza_liczba + druga_liczba
    print(pierwsza_liczba, "+", druga_liczba, "=", suma)

dodaj(5, 7)
dodaj(2012, 137)
dodaj(1234, 4321)

