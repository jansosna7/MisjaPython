# Escape - Misja Python 
# Autor: Sean McManus / www.sean.co.uk
# Wpisal: WPISZ SWOJE IMIE

import time, random, math

###############
##  ZMIENNE  ##
###############

WIDTH = 800 #rozmiar okna
HEIGHT = 800

#zmienne GRACZA
IMIE_GRACZA = "Sean" # zastap swoim imieniem!
IMIE_PRZYJACIELA1 = "Karen" # zastap imieniem swojego przyjaciela!
IMIE_PRZYJACIELA2 = "Leo" # zastap imieniem drugiego przyjaciela!
aktualny_pokoj = 31 # poczatkowy pokoj to 31

gora_lewa_x = 100
gora_lewa_y = 150

OBIEKTY_DEMO = [images.podloga, images.filar, images.gleba]

LADOWNIK_SEKTOR = random.randint(1, 24)
LADOWNIK_X = random.randint(2, 11)
LADOWNIK_Y = random.randint(2, 11)

ROZMIAR_KAFELKA = 30

###############
##   MAPA    ##
###############  

MAPA_SZEROKOSC = 5
MAPA_WYSOKOSC = 10 
MAPA_ROZMIAR = MAPA_SZEROKOSC * MAPA_WYSOKOSC

MAPA_GRY = [ ["Pokoj 0 - magazyn nieuzywanych obiektow", 0, 0, False, False] ]

pokoje_zewnetrzne = range(1, 26)
for sektoryplanety in range(1, 26): #tu generowane sa pokoje 1-25
    MAPA_GRY.append( ["Zapylona powierzchnia planety", 13, 13, True, True] )

MAPA_GRY  += [
        #["Nazwa pokoju", wysokosc, szerokosc, Gorne wyjscie?, Prawe wyjscie?]
        ["Sluza powietrzna", 13, 5, True, False], # pokoj 26
        ["Maszynownia", 13, 13, False, False], # pokoj 27
        ["Centrum sterowania Poodle", 9, 13, False, True], # pokoj 28
        ["Galeria widokowa", 9, 15, False, False], # pokoj 29
        ["Lazienka zalogi", 5, 5, False, False], # pokoj 30
        ["Przedsionek do sluzy powietrznej", 7, 11, True, True], # pokoj 31
        ["Pokoj z lewym wyjsciem", 9, 7, True, False], # pokoj 32
        ["Pokoj z prawym wyjsciem", 7, 13, True, True], # pokoj 33
        ["Laboratorium", 13, 13, False, True], # pokoj 34
        ["Szklarnia", 13, 13, True, False], # pokoj 35
        ["Sypialnia kpt. " + IMIE_GRACZA, 9, 11, False, False], # pokoj 36
        ["Zachodni korytarz", 15, 5, True, True], # pokoj 37
        ["Sala konferencyjna", 7, 13, False, True], # pokoj 38
        ["Swietlica zalogi", 11, 13, True, False], # pokoj 39
        ["Glowne centrum sterowania", 14, 14, False, False], # pokoj 40
        ["Izba chorych", 12, 7, True, False], # pokoj 41
        ["Zachodni korytarz", 9, 7, True, False], # pokoj 42
        ["Centrum infrastruktury technicznej", 9, 9, False, True], # pokoj 43
        ["Centrum zarzadzania systemami", 9, 11, False, False], # pokoj 44
        ["Wejscie do centrum sterowania", 7, 7, True, False], # pokoj 45
        ["Sypialnia plk. " + IMIE_PRZYJACIELA1, 9, 11, True, True], # pokoj 46
        ["Sypialnia plk. " + IMIE_PRZYJACIELA2, 9, 11, True, True], # pokoj 47
        ["Pokoj z systemem rur", 13, 11, True, False], # pokoj 48
        ["Biuro glownego naukowca", 9, 7, True, True], # pokoj 49
        ["Warsztat robotow", 9, 11, True, False] # pokoj 50
        ]

#proste sprawdzenie poprawnosci wpisanych powyzej danych mapy
assert len(MAPA_GRY)-1 == MAPA_ROZMIAR, "Rozmiar mapy nie pasuje do MAPA_GRY"


###############
##  OBIEKTY  ##
###############

obiekty = {
    0: [images.podloga, None, "Podloga jest czysta i blyszczaca"],
    1: [images.filar, images.pelny_cien, "Sciana jest gladka i zimna"],
    2: [images.gleba, None, "Wyglada jak pustynia"],
    3: [images.filar_niski, images.polcien, "Sciana jest gladka i zimna"],
    4: [images.lozko, images.polcien, "Czyste i wygodne lozko"],
    5: [images.stol, images.polcien, "Zrobiony z mocnego plastiku"],
    6: [images.krzeslo_lewe, None, "Krzeslo z miekkim siedziskiem"],
    7: [images.krzeslo_prawe, None, "Krzeslo z miekkim siedziskiem"],
    8: [images.regal_wysoki, images.pelny_cien,
        "Regal wypelniony podrecznikami"],
    9: [images.regal_niski, images.polcien,
        "Regal wypelniony podrecznikami"],
    10: [images.szafka, images.polcien,
         "Mala szafka do przechowywania przedmiotow osobistych"],
    11: [images.komputer_stacjonarny, images.polcien,
         "Komputer. Uzyj do sprawdzania stanu powietrza i energii"],
    12: [images.roslina, images.roslina_cien, "Krzaczek truskawki, wyhodowany na stacji"],
    13: [images.elektryczne1, images.polcien,
         "Systemy elektryczne do zasilania stacji kosmicznej"],
    14: [images.elektryczne2, images.polcien,
         "Systemy elektryczne do zasilania stacji kosmicznej"],
    15: [images.kaktus, images.kaktus_cien, "Au! Uwazaj na kaktusa!"],
    16: [images.krzew, images.krzew_cien,
         "Kosmiczna salata. Nieco zwiedla, ale niesamowite, ze rosnie na stacji!"],
    17: [images.rury1, images.rury1_cien, "Rury instalacji do uzdatniania wody"],
    18: [images.rury2, images.rury2_cien,
         "Rury systemu podtrzymywania zycia"],
    19: [images.rury3, images.rury3_cien,
         "Rury systemu podtrzymywania zycia"],
    20: [images.drzwi, images.drzwi_cien, "Drzwi bezpieczenstwa. Otwierane automatycznie \
przed astronautami w dzialajacych skafandrach."],
    21: [images.drzwi, images.drzwi_cien, "Drzwi sluzy powietrznej. \
Ze wzgledow bezpieczenstwa, do obslugi wymagaja 2 osob."],
    22: [images.drzwi, images.drzwi_cien, "Zamkniete drzwi. Potrzebna karta dostepu \
kpt. "+ IMIE_GRACZA ],
    23: [images.drzwi, images.drzwi_cien, "Zamkniete drzwi. Potrzebna karta dostepu \
plk. "+ IMIE_PRZYJACIELA1 ],
    24: [images.drzwi, images.drzwi_cien, "Zamkniete drzwi. Potrzebna karta dostepu \
plk. "+ IMIE_PRZYJACIELA2 ],
    25: [images.drzwi, images.drzwi_cien,
         "Zamkniete drzwi. Otwierane z glownego centrum sterowania"],
    26: [images.drzwi, images.drzwi_cien,
         "Zamkniete drzwi w maszynowni."],
    27: [images.mapa, images.pelny_cien,
         "Miejsce katastrofy to sektor: " \
         + str(LADOWNIK_SEKTOR) + " // X: " + str(LADOWNIK_X) + \
         " // Y: " + str(LADOWNIK_Y)],
    28: [images.skala_duza, images.skala_duza_cien,
         "Skala. Jej twarda chropowata powierzchnia przypomina piaskowiec", "skala"],
    29: [images.skala_mala, images.skala_mala_cien,
         "Maly, ale ciezki kawalek marsjanskiej skaly"],
    30: [images.krater, None, "Krater na powierzchni planety"],
    31: [images.ogrodzenie, None,
         "Ogrodzenie z gazy. Pomaga chronic stacje przed burza piaskowa"],
    32: [images.mechanizm, images.mechanizm_cien,
         "Jeden z eksperymentow naukowych. Delikatnie wibruje"],
    33: [images.ramie_robota, images.ramie_robota_cien,
         "Ramie robota, sluzy do podnoszenia ciezarow"],
    34: [images.sedes, images.polcien, "Lsniacy czystoscia sedes"],
    35: [images.zlew, None, "Zlew z biezaca woda", "kran"],
    36: [images.globus, images.globus_cien,
         "Wielki globus planety. Delikatnie podswietlony od wewnatrz"],
    37: [images.stol_laboratoryjny, None,
         "Stol laboratoryjny do analizy gleby i pylu planety"],
    38: [images.automat, images.pelny_cien,
         "Automat. Wymaga uzycia monet.", "automat"],
    39: [images.mata_podlogowa, None,
         "Czujnik nacisku blokujacy wychodzenie w pojedynke"],
    40: [images.statek_ratowniczy, images.statek_ratowniczy_cien, "Statek ratowniczy!"],
    41: [images.centrum_sterowania_misja, images.centrum_sterowania_misja_cien, \
         "Stanowiska centrum sterowania"],
    42: [images.przycisk, images.przycisk_cien,
         "Przycisk do otwierania automatycznie zamykanych drzwi w maszynowni"],
    43: [images.tablica, images.pelny_cien,
         "Tablica uzywana podczas spotkan organizacyjnych"],
    44: [images.okno, images.pelny_cien,
         "Okno z widokiem na powierzchnie planety"],
    45: [images.robot, images.robot_cien, "Robot sprzatajacy. Wylaczony."],
    46: [images.robot2, images.robot2_cien,
         "Nieskonfigurowany jeszcze robot do badania powierzchni planety."],
    47: [images.rakieta, images.rakieta_cien, "Jednoosobowy statek jest w naprawie"], 
    48: [images.toksyczna_podloga, None, "Toksyczna podloga - nie stawaj na niej!"],
    49: [images.dron, None, "Dron dostawczy"],
    50: [images.kula_energii, None, "Kula energii - niebezpieczna!"],
    51: [images.kula_energii2, None, "Kula energii - niebezpieczna!"],
    52: [images.komputer, images.komputer_cien,
         "Terminal do zarzadzania systemami stacji kosmicznej."],
    53: [images.notatnik, None,
         "Notatnik. Ktos cos w nim nagryzmolil.", "notatnik"],
    54: [images.guma_do_zucia, None,
         "Kawalek klejacej gumy do zucia. Smak truskawkowy.", "guma do zucia"],
    55: [images.yoyo, None, "Zabawka z cienkiej, mocnej linki i plastiku. \
Sluzy do eksperymentow antygrawitacyjnych", "Jojo kpt. " + IMIE_GRACZA],
    56: [images.nitka, None,
         "Kawalek cienkiej, mocnej linki", "kawalek linki"],
    57: [images.igla, None,
         "Ostra igla kaktusa", "igla kaktusa"],
    58: [images.igla_z_nitka, None,
         "Igla kaktusa z przymocowana linka", "igla z linka"],
    59: [images.butla, None,
         "Butla z tlenem przecieka.", "przeciekajaca butla z tlenem"],
    60: [images.butla, None,
         "Lata chyba sie trzyma!", "zalatana butla z tlenem"],
    61: [images.lustro, None,
         "Lustro rzuca aureole swiatla na sciane.", "lustro"], 
    62: [images.pojemnik_pusty, None,
         "Rzadko uzywany pojemnik z lekkiego plastiku", "pojemnik"],
    63: [images.pojemnik_pelny, None,
         "Ciezki pojemnik wypelniony woda", "pojemnik wypelniony woda"],
    64: [images.szmaty, None,
         "Tlusta szmata! Podnies tylko jesli musisz!", "tlusta szmata"], 
    65: [images.mlotek, None,
         "Mlotek. Byc moze nadaje sie do rozlupywania ...", "mlotek"],
    66: [images.lyzka, None, "Wielka metalowa łyzka", "lyzka"],
    67: [images.torebka_z_jedzeniem, None,
         "Saszetka z suszonym jedzeniem. Wymaga wody.", "suszone jedzenie"], 
    68: [images.jedzenie, None,
         "Saszetka z jedzeniem. Uzyj, aby odzyskac 100% energii.", "jedzenie gotowe do spozycia"], 
    69: [images.ksiazka, None, "Ksiazka ma tytul 'Nie panikuj' \
napisany duza, uspakajajaca czcionka", "ksiazka"], 
    70: [images.odtwarzacz_mp3, None,
         "Odtwarzacz MP3, z najnowszymi hitami", "odtwarzacz MP3"],
    71: [images.ladownik, None, "Poodle, maly statek do eksploracji kosmosu. \
Jego czarne pudelko zawiera radio.", "ladownik Poodle"],
    72: [images.radio, None, "System komunikacji radiowej z ladownika \
Poodle", "radio do komunikacji"],
    73: [images.modul_gps, None, "Modul GPS", "modul GPS"],
    74: [images.system_pozycjonowania, None, "Czesc systemu pozycjonowania. \
Potrzebuje modulu GPS.", "interfejs pozycjonowania"],
    75: [images.system_pozycjonowania, None,
         "Dzialajacy system pozycjonowania", "system pozycjonowania"],
    76: [images.nozyczki, None, "Nozyczki. Zbyt tepe, by cokolwiek przeciac. \
Czy mozesz je naostrzyc?", "tepe nozyczki"],
    77: [images.nozyczki, None,
         "Bardzo ostre nozyczki. Ostroznie!", "naostrzone nozyczki"],
    78: [images.moneta, None,
         "Mala moneta do uzycia w automatach na stacji",
         "moneta"],
    79: [images.karta_dostepu, None,
         "Ta karta dostepu nalezy do kpt. " + IMIE_GRACZA, "karta dostepu" ],
    80: [images.karta_dostepu, None,
         "Ta karta dostepu nalezy do plk. " + IMIE_PRZYJACIELA1, "karta dostepu" ],
    81: [images.karta_dostepu, None,
         "Ta karta dostepu nalezy do plk. " + IMIE_PRZYJACIELA2, "karta dostepu" ]
    }

gracz_moze_przenosic = list(range(53, 82))
# Ponizsze numery reprezentuja podloge, mate podlogowa, glebe i toksyczna podloge
gracz_moze_stac_na = gracz_moze_przenosic + [0, 39, 2, 48]


#################
## SCENOGRAFIA ##
#################

# Scenografia opisuje obiekty, ktorych nie mozna przenosic miedzy pokojami
# numer pokoju : [[numer obiektu, polozenie y, polozenie x]...]
scenografia = {
    26: [[39,8,2]],
    27: [[33,5,5], [33,1,1], [33,1,8], [47,5,2],
         [47,3,10], [47,9,8], [42,1,6]],
    28: [[27,0,3], [41,4,3], [41,4,7]],
    29: [[7,2,6], [6,2,8], [12,1,13], [44,0,1],
         [36,4,10], [10,1,1], [19,4,2], [17,4,4]],
    30: [[34,1,1], [35,1,3]],
    31: [[11,1,1], [19,1,8], [46,1,3]],
    32: [[48,2,2], [48,2,3], [48,2,4], [48,3,2], [48,3,3],
         [48,3,4], [48,4,2], [48,4,3], [48,4,4]],
    33: [[13,1,1], [13,1,3], [13,1,8], [13,1,10], [48,2,1],
         [48,2,7], [48,3,6], [48,3,3]],
    34: [[37,2,2], [32,6,7], [37,10,4], [28,5,3]],
    35: [[16,2,9], [16,2,2], [16,3,3], [16,3,8], [16,8,9], [16,8,2], [16,1,8],
         [16,1,3], [12,8,6], [12,9,4], [12,9,8],
         [15,4,6], [12,7,1], [12,7,11]],
    36: [[4,3,1], [9,1,7], [8,1,8], [8,1,9],
         [5,5,4], [6,5,7], [10,1,1], [12,1,2]],
    37: [[48,3,1], [48,3,2], [48,7,1], [48,5,2], [48,5,3],
         [48,7,2], [48,9,2], [48,9,3], [48,11,1], [48,11,2]],
    38: [[43,0,2], [6,2,2], [6,3,5], [6,4,7], [6,2,9], [45,1,10]],
    39: [[38,1,1], [7,3,4], [7,6,4], [5,3,6], [5,6,6],
         [6,3,9], [6,6,9], [45,1,11], [12,1,8], [12,1,4]], 
    40: [[41,5,3], [41,5,7], [41,9,3], [41,9,7],
         [13,1,1], [13,1,3], [42,1,12]],
    41: [[4,3,1], [10,3,5], [4,5,1], [10,5,5], [4,7,1],
         [10,7,5], [12,1,1], [12,1,5]],
    44: [[46,4,3], [46,4,5], [18,1,1], [19,1,3],
         [19,1,5], [52,4,7], [14,1,8]],
    45: [[48,2,1], [48,2,2], [48,3,3], [48,3,4], [48,1,4], [48,1,1]],
    46: [[10,1,1], [4,1,2], [8,1,7], [9,1,8], [8,1,9], [5,4,3], [7,3,2]],
    47: [[9,1,1], [9,1,2], [10,1,3], [12,1,7], [5,4,4], [6,4,7], [4,1,8]],
    48: [[17,4,1], [17,4,2], [17,4,3], [17,4,4], [17,4,5], [17,4,6], [17,4,7],
         [17,8,1], [17,8,2], [17,8,3], [17,8,4],
         [17,8,5], [17,8,6], [17,8,7], [14,1,1]],
    49: [[14,2,2], [14,2,4], [7,5,1], [5,5,3], [48,3,3], [48,3,4]], 
    50: [[45,4,8], [11,1,1], [13,1,8], [33,2,1], [46,4,6]] 
    }

suma_kontrolna = 0
licznik_kontrolny = 0
for klucz, lista_scenografii_pokoju in scenografia.items():
    for lista_elem_scenografii in lista_scenografii_pokoju:
        suma_kontrolna += (lista_elem_scenografii[0] * klucz
                     + lista_elem_scenografii[1] * (klucz + 1) 
                     + lista_elem_scenografii[2] * (klucz + 2))
        licznik_kontrolny += 1
print("Elementy scenografii: ", licznik_kontrolny)
assert licznik_kontrolny == 161, "Oczekiwano 161 elementow scenografii"
assert suma_kontrolna == 200095, "Blad w danych scenografii"
print("Suma kontrolna scenografii: " + str(suma_kontrolna))

for pokoj in range(1, 26):# Dodawanie losowej scenografii na zewnatrz.
    if pokoj != 13: # Pokoj 13 pominiety.
        elem_scenografii = random.choice([16, 28, 29, 30])
        scenografia[pokoj] = [[elem_scenografii, random.randint(2, 10),
                          random.randint(2, 10)]]
        
# Petle do dodania ogrodzen do pokoi na powierzchni planety.
for wspolrzedna_pokoju in range(0, 13):
    for numer_pokoju in [1, 2, 3, 4, 5]: # Dodanie gornego ogrodzenia
        scenografia[numer_pokoju] += [[31, 0, wspolrzedna_pokoju]]
    for numer_pokoju in [1, 6, 11, 16, 21]: # Dodanie lewego ogrodzenia
        scenografia[numer_pokoju] += [[31, wspolrzedna_pokoju, 0]]
    for numer_pokoju in [5, 10, 15, 20, 25]: # Dodanie prawego ogrodzenia
        scenografia[numer_pokoju] += [[31, wspolrzedna_pokoju, 12]]

del scenografia[21][-1] # Usuniecie ostatniego panelu z pokoju 21
del scenografia[25][-1] # Usuniecie ostatniego panelu z pokoju 25
           

####################
## TWORZENIE MAPY ##
####################

def sprawdz_typ_podlogi():
    if aktualny_pokoj in pokoje_zewnetrzne:
        return 2 # gleba
    else:
        return 0 # wykafelkowana podloga       

def generuj_mape():
# Ta funkcja tworzy mape aktualnego pokoju,
# przy uzyciu danych pokoju, scenografii i rekwizytow.
    global mapa_pokoju, szer_pokoju, wys_pokoju, nazwa_pokoju, mapa_zagrozen
    global gora_lewa_x, gora_lewa_y, ramka_przezroczystosci_sciany
    dane_pokoju = MAPA_GRY[aktualny_pokoj]
    nazwa_pokoju = dane_pokoju[0]
    wys_pokoju = dane_pokoju[1]
    szer_pokoju = dane_pokoju[2]

    typ_podlogi = sprawdz_typ_podlogi()
    if aktualny_pokoj in range(1, 21):
        dolny_brzeg = 2 #gleba
        boczny_brzeg = 2 #gleba
    if aktualny_pokoj in range(21, 26):
        dolny_brzeg = 1 #sciana
        boczny_brzeg = 2 #gleba
    if aktualny_pokoj > 25:
        dolny_brzeg = 1 #sciana
        boczny_brzeg = 1 #sciana

    # Tworzenie gornego rzedu mapy pokoju.
    mapa_pokoju=[[boczny_brzeg] * szer_pokoju]
    # Dodanie srodkowych rzedow mapy pokoju (sciana, posrodku podloga, sciana).
    for y in range(wys_pokoju - 2):
        mapa_pokoju.append([boczny_brzeg]
                        + [typ_podlogi]*(szer_pokoju - 2) + [boczny_brzeg])
    # Dodanie dolnego rzedu mapy pokoju .
    mapa_pokoju.append([dolny_brzeg] * szer_pokoju)

    # Dodanie wyjsc.
    srodkowy_rzad = int(wys_pokoju / 2)
    srodkowa_kolumna = int(szer_pokoju / 2)

    if dane_pokoju[4]: # Jesli pokoj ma prawe wyjscie
        mapa_pokoju[srodkowy_rzad][szer_pokoju - 1] = typ_podlogi
        mapa_pokoju[srodkowy_rzad+1][szer_pokoju - 1] = typ_podlogi
        mapa_pokoju[srodkowy_rzad-1][szer_pokoju - 1] = typ_podlogi

    if aktualny_pokoj % MAPA_SZEROKOSC != 1: # Jesli pokoj nie lezy po lewej stronie mapy
        pokoj_po_lewej = MAPA_GRY[aktualny_pokoj - 1]
        # Jesli pokoj po lewej ma prawe wyjscie, dodanie lewego wyjscia w tym pokoju
        if pokoj_po_lewej[4]: 
            mapa_pokoju[srodkowy_rzad][0] = typ_podlogi 
            mapa_pokoju[srodkowy_rzad + 1][0] = typ_podlogi
            mapa_pokoju[srodkowy_rzad - 1][0] = typ_podlogi

    if dane_pokoju[3]: # Jesli pokoj ma gorne wyjscie
        mapa_pokoju[0][srodkowa_kolumna] = typ_podlogi
        mapa_pokoju[0][srodkowa_kolumna + 1] = typ_podlogi
        mapa_pokoju[0][srodkowa_kolumna - 1] = typ_podlogi

    if aktualny_pokoj <= MAPA_ROZMIAR - MAPA_SZEROKOSC: # Jesli pokoj nie lezy w dolnym rzedzie
        pokoj_ponizej = MAPA_GRY[aktualny_pokoj+MAPA_SZEROKOSC]
        # Jesli pokoj ponizej ma gorne wyjscie, dodanie dolnego wyjscia w tym pokoju
        if pokoj_ponizej[3]: 
            mapa_pokoju[wys_pokoju-1][srodkowa_kolumna] = typ_podlogi 
            mapa_pokoju[wys_pokoju-1][srodkowa_kolumna + 1] = typ_podlogi
            mapa_pokoju[wys_pokoju-1][srodkowa_kolumna - 1] = typ_podlogi

###############
## EKSPLORER ##
############### 

def draw():
    global wys_pokoju, szer_pokoju, mapa_pokoju
    generuj_mape()
    screen.clear()
    mapa_pokoju[2][4] = 7
    mapa_pokoju[2][6] = 6
    mapa_pokoju[1][1] = 8
    mapa_pokoju[1][2] = 9
    mapa_pokoju[1][8] = 12
    mapa_pokoju[1][9] = 9

    for y in range(wys_pokoju):
        for x in range(szer_pokoju):
            obraz_do_narysowania = obiekty[mapa_pokoju[y][x]][0]
            screen.blit(obraz_do_narysowania,
                (gora_lewa_x + (x*30),
                 gora_lewa_y + (y*30) - obraz_do_narysowania.get_height()))

def ruch():
    global aktualny_pokoj
    stary_pokoj = aktualny_pokoj
    
    if keyboard.left:
        aktualny_pokoj -= 1
    if keyboard.right:
        aktualny_pokoj += 1
    if keyboard.up:
        aktualny_pokoj -= MAPA_SZEROKOSC
    if keyboard.down:
        aktualny_pokoj += MAPA_SZEROKOSC

    if aktualny_pokoj > 50:
        aktualny_pokoj = 50
    if aktualny_pokoj < 1:
        aktualny_pokoj = 1

    if aktualny_pokoj != stary_pokoj:
        print("Wchodzisz do pokoju:" + str(aktualny_pokoj))

clock.schedule_interval(ruch, 0.08)

