planety = { "Merkury": "Najmniejsza planeta, najblizej Slonca",
            "Wenus": "Obrot planety Wenus zajmuje 243 dni",
            "Ziemia": "Jedyna znana planeta, na ktorej rozwinelo sie zycie",
            "Mars": "Czerwona planeta to druga po Merkurym najmniejsza planeta",
            "Jowisz": "Najwieksza planeta Jupiter jest gazowym olbrzymem",
            "Saturn": "Gazowy olbrzym, drugi pod wzgledem wielkosci",
            "Uran": "Lodowy olbrzym z systemem pierscieni",
            "Neptun": "Lodowy olbrzym i najdalej od Slonca",
            "Pluton": "Najwieksza planeta karlowata w Ukladzie Slonecznym"
            }

while True:
   pytanie = input("Ktora planeta Cie interesuje? ")
   print(planety[pytanie])
