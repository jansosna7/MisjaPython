Ten folder zawiera pliki kod, obrazów i dźwięków stanowiące materiały pomocniczne książki Seana McManusa zatytułowanej Misja Python.

Autor kodu i efektów dźwiękowych: Sean McManus (www.sean.co.uk)
Grafika: Rafael Pimenta

Możecie użyć tych materiałów do tworzenia własnych gier Python, o ile zamieścicie informacje o ich pochodzeniu i nie będziecie sprzedawać lub czerpać innych korzyści finansowych z tych gier.

Aby dowiedzieć się więcej o tej książce, odwiedźcie stronę:
http://www.sean.co.uk/books/mission-python/

Informacje na temat innych książek Seana m.in. Cool Scratch Projects in Easy Steps oraz Raspberry Pi For Dummies znaleźć można na stronie:
http://www.sean.co.uk/books/index.shtm
